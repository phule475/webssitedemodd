from odoo import models, fields

class SurveySurvey(models.Model):
    _inherit = 'survey.survey'

    category_id = fields.Many2one(
        'survey.category',
        string="Category",
        help="Select a category to group this survey."
    )
