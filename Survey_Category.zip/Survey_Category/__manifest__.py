{
    "name": "Survey Category",
    "version": "17.0.1.0.0",
    "category": "Surveys",
    "summary": "Add category field to surveys for better classification",
    "description": """
        This module allows users to categorize surveys using a category model.
        Surveys can be grouped and filtered by category.
    """,
    "author": "Your Company",
    "website": "https://yourcompany.com",
    "license": "LGPL-3",
    "depends": ["survey"],
    "data": [
        "security/ir.model.access.csv",
        "views/survey_category_views.xml",
        "views/survey_survey_views.xml",
        "data/survey_category_data.xml"
    ],
    "installable": True,
    "application": False,
    "auto_install": False
}