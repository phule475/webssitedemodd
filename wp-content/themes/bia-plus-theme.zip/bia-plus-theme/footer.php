<footer>
    <!-- Nội dung footer (tùy chỉnh theo ý bạn) -->
    <p>&copy; 2025 Bia +</p>
</footer>